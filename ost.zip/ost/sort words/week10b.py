my_str= input("Enter the string to be sorted:")
words = [word.lower() for word in my_str.split()]
words.sort()
print("The sorted words are:")
for word in words:
   print(word,end=" ")
