<?php
if($_POST)
{
	$servername="localhost";
	$username="root";
	$password="";
	$database_name="Test_DB";
	
	$user=$_POST['user'];
	$pwd=$_POST['pwd'];
	

	$conn=mysqli_connect($servername,$username,$password,$database_name);
	if (!$conn) 
	{
    	die("Connection failed: " . mysqli_connect_error);
	}
	$sql = "SELECT * from Login where user='$user' and pwd='$pwd'";
	$result = mysqli_query($conn,$sql);

	if(mysqli_num_rows($result)==1)
	{
		session_start();
		$_SESSION['auth']='true';
		header('location:welcome.php');
	}
	else
	{
		echo 'Wrong Username or Password! :( ' ;
	}
}
?>


<html>
<head>
<title>Login Page</title>
</head>
<body>
<center>
<form method="POST" action="">
UserName:<input type="text" name="user"></br>
Password:<input type="password" name="pwd"></br>
<input type="submit" value="submit">
</form>
</body>
</html>
