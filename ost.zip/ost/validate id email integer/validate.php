<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {


$int = $_POST['int']; 
$ip = $_POST['ip']; 
$email = $_POST['email'];

if (filter_var($int, FILTER_VALIDATE_INT) === 0 || !filter_var($int, FILTER_VALIDATE_INT) === false) {
    $int_error="Valid Integer:)";
  } else {
    $int_error="Invalid Integer :(";
  }

  if (!filter_var($ip, FILTER_VALIDATE_IP) === false) {
    $ip_error="Valid IP Address :)";
  } else {
    $ip_error="Invalid IP Address :(";
  }

  $email = filter_var($email, FILTER_SANITIZE_EMAIL);

// Validate e-mail
if (!filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
 $email_error="Valid email:)";
} else {
    $email_error="Invalid email:(";
}
}
?>

<html>
    <head>
    </head>
    <body>
        <center>
        <h1>Validate your data</h1>
        <form action="" method="POST">
            Integer:<input type="text" name="int"><span><?php if(isset($int_error)){echo $int_error;}?></span><br>
            IP Address:<input type="text" name="ip"><?php if(isset($ip_error)){echo $ip_error;}?></span><br>
            Email:<input type="text" name="email"><?php if(isset($email_error)){echo $email_error;}?></span><br>
            <input type="submit" name="submit">
        </form>
    </body>
</html>