<html>
<head>
<title>Cookies Demo</title>
</head>
<body>
<center>
<a href="create.php">Create Cookie</a><br>
<a href="show.php">Show Created Cookies</a><br>
<a href="delete.php">Delete Cookie</a><br>
<a href="session.php">Delete Session</a><br>
<?php    
session_start(); 
if(!isset($_SESSION['page_count']))
{     
$_SESSION['page_count'] = 1;
 
}
else
{   
  $_SESSION['page_count'] += 1; 
}
echo 'You are visitor number ' . $_SESSION['page_count'];
?>
</center>
</body>
</html>

