<?php   
setcookie("user", "sai", time() - 360,'/'); 
header('Location: cookie.php');  
?>
