m=int(input("Enter no. of rows for A"))
n=int(input("Enter no.of columns for A"))
p=int(input("Enter no. of rows for B"))
q=int(input("Enter no.of columns for B"))

if(n!=p):
	print("Multiplication cannot be done!")
	exit()
A=[]  
print("Enter values for matrix A")
for i in range(m):
	a=[]
	for j in range(n):
		a.append(int(input()))
	A.append(a)

print("Enter values for matrix B")	
B=[]
for i in range(p):
	a=[]
	for j in range(q):
		a.append(int(input()))
	B.append(a)
		
result=[]
for i in range(n):
	a=[]
	for j in range(p):
		a.append(0)
	result.append(a) 

print("Multiplication of A and B is:")
for i in range(m): 
    for j in range(q): 
        for k in range(len(B)): 
            result[i][j] += A[i][k] * B[k][j] 
  
for r in result: 
    print(r) 
