<html>
<head>
</head>
<body>
<form action="up.php" method="POST" enctype="multipart/form-data">
   <input type="file" name="uploadfile" />
   <input type="submit" name="upload"/>
</form>   
<a href="disp.php">Display Image</a>
<div>

</body>
</html>

