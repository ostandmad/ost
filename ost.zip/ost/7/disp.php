<?php 
error_reporting(0); 
?> 
<?php 
$db = mysqli_connect("localhost", "root", "", "Test_DB"); 
if ($db->connect_error) 
{
  die("Connection failed: " . $conn->connect_error);
}
$sql = "select * from Images"; 
$result=mysqli_query($db, $sql); 
while($row=mysqli_fetch_array($result))
{
echo "<div> <img src='".$row[1]."'></div>";
}
?>
		
