<?php
$q = $_GET['q'];
$con = mysqli_connect('localhost','root','','Test_DB');
if (!$con) {
  die('Could not connect: ' . mysqli_error($con));
}
$sql="SELECT * FROM search WHERE name like '%$q%'";
$result = mysqli_query($con,$sql);

echo "<br>";
while($row = mysqli_fetch_array($result)) {
echo $row['name'];
echo "<br>";
}
?>
