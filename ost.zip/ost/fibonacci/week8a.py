a=0
b=1
c=1
n=int(input("Enter the value for n:"))
i=1
while(i<=n):
	c=a+b
	print(b,end=" ")
	a=b
	b=c
	i=i+1
print()

	
