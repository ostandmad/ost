<?php
$servername="localhost";
$username="root";
$password="";
$database_name="Test_DB";
$conn=mysqli_connect($servername,$username,$password,$database_name);
if (!$conn) 
{
    die("Connection failed: " . mysqli_connect_error);
}
$sql = "SELECT eid,ename,salary FROM Employee";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
 
  while($row = $result->fetch_assoc()) {
    echo "id: " . $row["eid"]. " - Name: " . $row["ename"]. " " . $row["salary"]. "<br>";
  }
} else {
  echo "0 results";
}
$conn->close();
?>
