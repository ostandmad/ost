<?php
$lines = file('sample1.txt');
$lines2 = file('sample2.txt');

foreach ($lines as $key => $val)
{
     $lines[$key] = $val.$lines2[$key];
}
file_put_contents('sample3.txt', implode("", $lines));

/*file_put_contents('sample3.txt', implode("", $lines));
file_put_contents('sample3.txt', implode("", $lines2)  ,FILE_APPEND);*/
?>
