<?php 
error_reporting(0); 
?> 
<?php 
$msg = ""; 
if (isset($_POST['upload']))
 { 
	$filename = $_FILES["uploadfile"]["name"]; 
	$tempname = $_FILES["uploadfile"]["tmp_name"];
	$db = mysqli_connect("localhost", "root", "", "Test_DB"); 
	if ($db->connect_error) 
	{
  		die("Connection failed: " . $conn->connect_error);
	}	
	$sql = "INSERT INTO Images (image) VALUES ('$filename')"; 	
	mysqli_query($db, $sql); 	
	if (move_uploaded_file($tempname, $filename))
	{ 
		$msg = "Image uploaded successfully"; 
	}
	else
	{ 
		$msg ="Failed to upload image"; 
	}
echo $msg;
} 
?> 

