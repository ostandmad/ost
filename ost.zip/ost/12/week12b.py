import mysql.connector
import sys

def show():
	try:
		cursor.execute("select * from student")
		values=cursor.fetchall()
		for i in values:
			print(i[0],i[1],i[2])
	except Exception as arg:
		print(arg)
		sys.exit()
		
def delete():
	id1=int(input(("Please enter id to delete:")))
	try:
		sql = "DELETE FROM student WHERE id = %s"
		adr = (id1, )

		cursor.execute(sql, adr)

		conn.commit()
		print("deleted rows with id=",id1)
	except Exception as arg:
		print(arg)
		sys.exit()


def insert():
	id1=int(input("Enter id:"))
	name=input("Enter name:")
	class1=input("Enter class:")
	try:

		sql = "INSERT INTO student (id,name,class) VALUES (%s,%s,%s)"
		val = (id1,name,class1)
		cursor.execute(sql, val)
		conn.commit()
	except Exception as arg:
		print(arg)
		sys.exit()
	print("One row inserted")
		

conn=mysql.connector.connect(host="localhost",user="username",password="Shashank@123",database="school")

#print(mysql.connector.__version__);
cursor=conn.cursor()
print("Select operation.")
print("1.Insert")
print("2.Show")
print("3.Delete")
print("4.Exit")

while True:
    choice = input("Enter choice(1/2/3/4): ")


    if choice in ('1', '2', '3', '4'):
        if choice == '1':
        	insert()
        elif choice == '2':
        	show()
        elif choice == '3':
        	delete()
        elif choice == '4':
        	sys.exit()
        



