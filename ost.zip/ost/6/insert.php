<?php
$servername="localhost";
$username="root";
$password="";
$database_name="Test_DB";
$roll=$_POST['roll'];
$name=$_POST['name'];
$branch=$_POST['branch'];
$age=$_POST['age'];
$email=$_POST['email'];
$phone=$_POST['phone'];

$conn = new mysqli($servername, $username, $password, $database_name);
if ($conn->connect_error) 
{
  die("Connection failed: " . $conn->connect_error);
}
$sql = "INSERT INTO Student (roll,name,branch,age,email,phone)
VALUES ('$roll','$name','$branch','$age','$email','$phone')";
if ($conn->query($sql) === TRUE) 
{
  echo "New record created successfully:)";
} 
else 
{
  echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
?>
