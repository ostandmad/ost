<?php
$output ='test.zip';
$input ='sample2.txt';
$zip=new ZipArchive;
if($zip->open($output,ZipArchive::CREATE)==TRUE)
{
$zip->addFile($input);
$zip->close();
}
echo 'ZIP Successful!';
?>
