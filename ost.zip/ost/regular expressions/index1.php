<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {


$name = $_POST['name']; 
$email = $_POST['email']; 
$user = $_POST['user']; 
$pwd = $_POST['pwd']; 
$gender = $_POST['gender']; 

$name_error="";
$email_error="";
$user_error="";
$pwd_error="";
$gender_error="";

$count=0;

if (!preg_match('/^[a-z A-Z]+$/',$name))  // Full Name
{
$name_error="<span style='color:red'>&#x2717;</span>"."Please Enter only alphabets";
$count=$count+1;
}

if (!preg_match('/^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/', $email))  // Email
{
$email_error="<span style='color:red'>&#x2717;</span>"."Please enter valid email format";
$count=$count+1;
}

if (!preg_match('/^[a-z A-Z \d \. _]{2,20}+$/',$user))  // Usename min 2 char max 20 char
{
$user_error="<span style='color:red'>&#x2717;</span>"."Please enter minimum 2 characters";
$count=$count+1;
}

if (!preg_match('/^[a-z A-Z \d \w]{6,20}+$/',$pwd)) 
{
$pwd_error="<span style='color:red'>&#x2717;</span>"."Please enter minimum 6 characters";
$count=$count+1;
}

if ($gender==0)  // Gender
{
$gender_error="<span style='color:red'>&#x2717;</span>"."Please select any one"; 
$count=$count+1;
}

if($count==0)
{
header("Location: thanks.html");
}
else{

 }
 
}
?>

<html>
<head>
</head>
<body>
<center>
<h1>Please Fill the Form</h1>
<form method="POST" action="">
Name:<input type="text" name="name">
	  <span><?php if(isset($name_error)){echo $name_error;}?></span></br>
Email:<input type="text" name="email">
	  <span><?php if(isset($email_error)){echo $email_error;}?></span></br>
Username:<input type="text" name="user">
	  <span><?php if(isset($user_error)){echo $user_error;}?></span></br>
Password:<input type="text" name="pwd">
	  <span><?php if(isset($pwd_error)){echo $pwd_error;}?></span></br>
Gender :  <select name="gender"> 
	  <option value="0">Gender</option>
	  <option value="1">Male</option>
	  <option value="2">Female</option> 
	  </select>
<span><?php if(isset($gender_error)){echo $gender_error;}?></span></br>

<input type="submit" name="submit">   

</form>
</center>
</body>
</html>
