l=list(map(int,input("Enter list of numbers").split()))

def max_in_list(l):
	if len(l) == 1:
		return l[0]
	m = max_in_list(l[1:])
	return max(l[0],m)

print(max_in_list(l))
